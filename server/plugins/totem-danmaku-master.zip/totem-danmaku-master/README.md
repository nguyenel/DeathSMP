# totem-danmaku

![Screenshot](screenshot.png)

Totem-danmaku brings danmaku comment support to Totem player (Gnome Video). 
This enables Totem users to load danmaku comments both locally and remotely and 
play it along with the current video.

### License
Totem-danmaku is licensed under the MIT License. It also uses core design 
concepts from CommentCoreLibrary.

### Current Status
Currently we're still in the alpha stage of development. Be prepared for 
instability.

# totem弹幕支持
Totem-danmaku 为Totem播放器提供附加弹幕支持。这将允许Totem播放器的用户（如大部分Gnome用户）可以
方便的载入离线或者在线弹幕文件，并伴随目前视频一同播放。

### 许可
Totem-danmaku 以 MIT 许可 发行。其中用到了同样是 MIT 许可下的 CommentCoreLibrary 的核心
设计思想。

### 项目状态
目前项目还在alpha试验性阶段，有时的最新版可能会导致你的播放器不稳定。请做好心理准备。
