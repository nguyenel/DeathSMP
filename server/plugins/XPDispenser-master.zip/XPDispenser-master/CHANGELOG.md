# Changelog

## [1.2.0] - 2024-01-30

* Fixed decreasing player's experience points while sneak-right-clicking the sign

## [1.1] - 2023-08-20

* Prevent editing sign with right click implemented with Minecraft 1.20
* Now requires at least Minecraft 1.20.1

## [1.0] - 2021-01-21

Initial release